﻿namespace BashSoft
{
    class Launcher
    {
        static void Main()
        {
            InputReader.StartReadingCommands();
        }
    }
}